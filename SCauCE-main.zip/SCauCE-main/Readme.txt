


# Prepare data
python prepareData.py

# Train model
python Train.py --config conf/PEMSD8_1dim_12.conf


# Dataset used: PEMS08, PEMS07, EMS04, PEMS03

